var quotes=['Of all sad words of tongue or pen, the saddest are these, It might have been.',
'Words are, of course, the most powerful drug used by mankind',
'Words can be like X-rays if you use them properly -- they’ll go through anything. You read and you’re pierced',
'A classic is a book that has never finished saying what it has to say.',
'Words are pale shadows of forgotten names. As names have power, words have power. Words can light fires in the minds of men. Words can wring tears from the hardest hearts',
'She read books as one would breathe air, to fill up and live.',
'She had always wanted words, she loved them; grew up on them. Words gave her clarity, brought reason, shape.',
'I like good strong words that mean something…',
'Sweet words are like honey, a little may refresh, but too much gluts the stomach',
'Words are a pretext. It is the inner bond that draws one person to another, not words.',
'I believe in the magic and authority of words.'

]
function newQuote(){
    var randomNumber=Math.floor(Math.random()*(quotes.length));
    document.getElementById('quoteDisplay').innerHTML=quotes[randomNumber];

}